package kaj.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kaj.dao.applicationDAO;
import kaj.model.application;

/**
 *  THIS IS DIRECTED FROM reference.jsp AND SEND IT BACK AGAIN TO SHOW THE APPLICATION DATA TABLE
 * @author chongthamkaj
 *
 */

@WebServlet("/getReport")
public class getapplicationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
			
			
			applicationDAO applicationdao = new applicationDAO();
			request.setAttribute("success", "Application Added Successfully");
			List<application> applications = applicationdao.selectAll();
		
		
		request.setAttribute("Applications", applications);	
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/reference.jsp");
			rd.forward(request, response);
		}
	}


