package kaj.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kaj.dao.applicationDAO;
import kaj.model.application;

/**
 *  THIS IS DIRECTED FROM reference.jsp AND SEND IT TO downloadreport.jsp
 * @author chongthamkaj
 *
 */

@WebServlet("/getdownload")
public class getreviewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
			
			String ref = request.getParameter("newreport");
			String paidd = request.getParameter("paid");
			String openn = request.getParameter("open");
			
			
			applicationDAO applicationdao = new applicationDAO();
			
			request.setAttribute("reff", ref);
			request.setAttribute("opn", openn);
			request.setAttribute("pad", paidd);
			
			
			List<application> applications = applicationdao.selectAll();
			request.setAttribute("Applications", applications);
			
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/downloadreport.jsp");
			rd.forward(request, response);
		}
	}


