package kaj.servlets;

import java.io.IOException;
//import java.util.List;
import java.util.*;
import java.sql.ResultSet;
import java.sql.SQLException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kaj.dao.applicationDAO;
import kaj.model.application;
import kaj.model.incentive;
import kaj.dao.incentiveDAO;

/**
 *  THIS SERVLET IS USED BY applications.jsp AND REDIRECT TO viewApplication.jsp. 
 * @author chongthamkaj
 *
 */

@WebServlet("/addApplication")
public class applicationServlet extends HttpServlet 
	{
		private static final long serialVersionUID = 1L;
	
		private applicationDAO applicationDAO;
		
	
		public void init() 
		{
			applicationDAO = new applicationDAO();
		}

  
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
		{
			
			// THIS WILL GET THE DATA FROM application.jsp
			
				String ptitle = request.getParameter("ptitle");
				String jrname = request.getParameter("jrname");
				String doi = request.getParameter("doi");
				String jcat = request.getParameter("jcat");
				String firstauthor = request.getParameter("firstauthor");
				String fauthor = request.getParameter("fauthor");
				String seauthor = request.getParameter("seauthor");
				String secondauthor = request.getParameter("secondauthor");
				String sauthor = request.getParameter("sauthor");
				String thauthor = request.getParameter("thauthor");
				String thirdauthor = request.getParameter("thirdauthor");
				String tauthor = request.getParameter("tauthor");
				String otherauthor = request.getParameter("otherauthor");
				Date today = new Date();
				String date = today.toString();
				String refdate1 = date.replaceAll("\\s+", "");
				String refdate = refdate1.toUpperCase();
		
				// VALIDATION
				
				if ((ptitle == null || ptitle.contentEquals("") || ptitle.contentEquals(" ")) || 
					(jrname == null || jrname.equals("") || jrname.contentEquals(" ")) ||
					(doi == null || doi.equals("") || doi.contentEquals(" ")) ||
					(jcat == null || jcat.contentEquals("")) ||
					(firstauthor == null || firstauthor.contentEquals("") || firstauthor.contentEquals(" ")) ||
					(fauthor == null || fauthor.contentEquals(""))
				//	(secondauthor == null || secondauthor.contentEquals("")) ||
				//	(sauthor == null || sauthor.contentEquals("")) ||
				//	(thirdauthor == null || thirdauthor.contentEquals("")) ||
				//	(tauthor == null || tauthor.contentEquals(""))
						)
				{
					request.setAttribute("error", "Fill up Mandatory fields");
					RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
					rd.forward(request, response);
				} 
				else 
				{ 
					// GETTING AND PUTTING DATA
					
					application a = new application();
					
					a.setREFNO(refdate);
					a.setTitle(ptitle);
					a.setjournal(jrname);
					a.setDOI(doi);
					a.setJCAT(jcat);
					a.setFIRSTAUTHOR(firstauthor);
					a.setFAUTHOR(fauthor);
					a.setSEAUTHOR(seauthor);
					a.setSECONDAUTHOR(secondauthor);
					a.setSAUTHOR(sauthor);
					a.setTHAUTHOR(thauthor);
					a.setTHIRDAUTHOR(thirdauthor);
					a.setTAUTHOR(tauthor);
					a.setOTHERAUTHOR(otherauthor);
			
				/**
				 *   THIS incentiveDAO IS DEFINED IN src/kaj.dao/incentiveDAO		
				 */
					
					incentiveDAO incentiveDAO = new incentiveDAO(); 
					incentive rs = incentiveDAO.selectUser(2);  		// DON'T CHANGE THIS VALUE "2", IT IS ID OF THE AMOUNT TABLE
					int q1faculty = rs.getQ1faculty();
					int q1 = rs.getQ1();
					int q2 = rs.getQ2();
					int q3 = rs.getQ3();
					int q4 = rs.getQ4();
					
				
				/**
				 * 	CONDITIONS FOR DISTRIBUTION OF INCENTIVE AMOUNT FOR THE FACULTIES
				 */
					
					if(jcat.contentEquals("Q1") && firstauthor.contentEquals("Faculty") && seauthor.contentEquals("no") && thauthor.contentEquals("no")) 
					{
						a.setTOTALINCENTIVE(q1faculty);
					} 
					else if(jcat.contentEquals("Q1") && seauthor.contentEquals("yes") && thauthor.contentEquals("yes"))	
					{
						a.setTOTALINCENTIVE(q1);
					} 
					else if(jcat.contentEquals("Q2")) 
					{
						a.setTOTALINCENTIVE(q2);
					} 
					else if(jcat.contentEquals("Q3"))	
					{
						a.setTOTALINCENTIVE(q3);
					} 
					else if(jcat.contentEquals("Q4"))	
					{
						a.setTOTALINCENTIVE(q4);
					}
					
					// incentives calculation for condition 1 
			
					if(fauthor.contentEquals("Faculty") && seauthor.contentEquals("NIL") && thauthor.contentEquals("NIL"))
					{
						if(jcat.contentEquals("Q1"))
						{
							a.setINCENTIVEF(q1faculty);
							a.setINCENTIVES(0);
							a.setINCENTIVET(0);
						}
						else if(jcat.contentEquals("Q2"))
						{
							a.setINCENTIVEF(q2);
							a.setINCENTIVES(0);
							a.setINCENTIVET(0);
						}
						else if(jcat.contentEquals("Q3"))
						{
							a.setINCENTIVEF(q3);
							a.setINCENTIVES(0);
							a.setINCENTIVET(0);
						}
						else if(jcat.contentEquals("Q4"))
						{
							a.setINCENTIVEF(q4);
							a.setINCENTIVES(0);
							a.setINCENTIVET(0);
						}
					} 
			
					// incentives calculation for condition 2a
			
			else if(((fauthor.contentEquals("Faculty") && sauthor.contentEquals("Student")) || (fauthor.contentEquals("Faculty") && sauthor.contentEquals("External"))) && thauthor.contentEquals("NIL"))
				{
					if(jcat.contentEquals("Q1"))
					{
						a.setINCENTIVEF(q1);
						a.setINCENTIVES(0);
						a.setINCENTIVET(0);
					}
					else if(jcat.contentEquals("Q2"))
					{
						a.setINCENTIVEF(q2);
						a.setINCENTIVES(0);
						a.setINCENTIVET(0);
					}
					else if(jcat.contentEquals("Q3"))
					{
						a.setINCENTIVEF(q3);
						a.setINCENTIVES(0);
						a.setINCENTIVET(0);
					}
					else if(jcat.contentEquals("Q4"))
					{
						a.setINCENTIVEF(q4);
						a.setINCENTIVES(0);
						a.setINCENTIVET(0);
					}
				}
						
			// incentives calculation for condition 2b
			
			else if(((fauthor.contentEquals("Student") || fauthor.contentEquals("External")) && sauthor.contentEquals("Faculty")) && thauthor.contentEquals("NIL"))
			{
				if(jcat.contentEquals("Q1"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(q1);
					a.setINCENTIVET(0);
				}
				else if(jcat.contentEquals("Q2"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(q2);
					a.setINCENTIVET(0);
				}
				else if(jcat.contentEquals("Q3"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(q3);
					a.setINCENTIVET(0);
				}
				else if(jcat.contentEquals("Q4"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(q4);
					a.setINCENTIVET(0);
				}
			}
			
			
			// incentives calculation for condition 2c
			else if((fauthor.contentEquals("Faculty") && sauthor.contentEquals("Faculty") && thauthor.contentEquals("NIL")))
					{
				if(jcat.contentEquals("Q1"))
				{
					a.setINCENTIVEF(q1/2);
					a.setINCENTIVES(q1/2);
					a.setINCENTIVET(0);
				}
				else if(jcat.contentEquals("Q2"))
				{
					a.setINCENTIVEF(q2/2);
					a.setINCENTIVES(q2/2);
					a.setINCENTIVET(0);
				}
				else if(jcat.contentEquals("Q3"))
				{
					a.setINCENTIVEF(q3/2);
					a.setINCENTIVES(q3/2);
					a.setINCENTIVET(0);
				}
				else if(jcat.contentEquals("Q4"))
				{
					a.setINCENTIVEF(q4/2);
					a.setINCENTIVES(q4/2);
					a.setINCENTIVET(0);
				}
					}
			
		
			
			// incentives calculation for condition 3a
			else if(fauthor.contentEquals("Faculty") && (sauthor.contentEquals("Student") || sauthor.contentEquals("External")) && (tauthor.contentEquals("Student") || tauthor.contentEquals("External"))) 
					{
						if(jcat.contentEquals("Q1"))
						{
							a.setINCENTIVEF(q1);
							a.setINCENTIVES(0);
							a.setINCENTIVET(0);
						}
						else if(jcat.contentEquals("Q2"))
						{
							a.setINCENTIVEF(q2);
							a.setINCENTIVES(0);
							a.setINCENTIVET(0);
						}
						else if(jcat.contentEquals("Q3"))
						{
							a.setINCENTIVEF(q3);
							a.setINCENTIVES(0);
							a.setINCENTIVET(0);
						}
						else if(jcat.contentEquals("Q4"))
						{
							a.setINCENTIVEF(q4);
							a.setINCENTIVES(0);
							a.setINCENTIVET(0);
						}
					}
			
			
			
			// incentives calculation for condition 3b
			else if(fauthor.contentEquals("Student") && sauthor.contentEquals("Faculty") && (tauthor.contentEquals("Student") || tauthor.contentEquals("External")))
				
					{
						if(jcat.contentEquals("Q1"))
						{
							a.setINCENTIVEF(0);
							a.setINCENTIVES(q1);
							a.setINCENTIVET(0);
						}
						else if(jcat.contentEquals("Q2"))
						{
							a.setINCENTIVEF(0);
							a.setINCENTIVES(q2);
							a.setINCENTIVET(0);
						}
						else if(jcat.contentEquals("Q3"))
						{
							a.setINCENTIVEF(0);
							a.setINCENTIVES(q3);
							a.setINCENTIVET(0);
						}
						else if(jcat.contentEquals("Q4"))
						{
							a.setINCENTIVEF(0);
							a.setINCENTIVES(q4);
							a.setINCENTIVET(0);
						}
					}
			
			// incentives calculation for condition 3c
			
			else if(fauthor.contentEquals("External") && sauthor.contentEquals("Faculty") && (tauthor.contentEquals("Student") || tauthor.contentEquals("External)")))
					{
							if(jcat.contentEquals("Q1"))
							{
								a.setINCENTIVEF(0);
								a.setINCENTIVES(q1/2);
								a.setINCENTIVET(0);
							}
							else if(jcat.contentEquals("Q2"))
							{
								a.setINCENTIVEF(0);
								a.setINCENTIVES(q2/2);
								a.setINCENTIVET(0);
							}
							else if(jcat.contentEquals("Q3"))
							{
								a.setINCENTIVEF(0);
								a.setINCENTIVES(q3/2);
								a.setINCENTIVET(0);
							}
							else if(jcat.contentEquals("Q4"))
							{
								a.setINCENTIVEF(0);
								a.setINCENTIVES(q4/2);
								a.setINCENTIVET(0);
							}
					}
			
			// incentive calculation for condition 3d
			else if((fauthor.contentEquals("Student") || fauthor.contentEquals("External")) && (sauthor.contentEquals("Student") || sauthor.contentEquals("External")) && tauthor.contentEquals("Faculty"))
			{
				if(jcat.contentEquals("Q1"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(0);
					a.setINCENTIVET(q1/2);
				}
				else if(jcat.contentEquals("Q2"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(0);
					a.setINCENTIVET(q2/2);
				}
				else if(jcat.contentEquals("Q3"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(0);
					a.setINCENTIVET(q3/2);
				}
				else if(jcat.contentEquals("Q4"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(0);
					a.setINCENTIVET(q4/2);
				}
			}
			
			// incentive calculation for condition 3e
			
			else if(fauthor.contentEquals("Faculty") && sauthor.contentEquals("Faculty") && (tauthor.contentEquals("Student") || tauthor.contentEquals("External")))
			{
				if(jcat.contentEquals("Q1"))
				{
					a.setINCENTIVEF(q1/2);
					a.setINCENTIVES(q1/2);
					a.setINCENTIVET(0);
				}
				else if(jcat.contentEquals("Q2"))
				{
					a.setINCENTIVEF(q2/2);
					a.setINCENTIVES(q2/2);
					a.setINCENTIVET(0);
				}
				else if(jcat.contentEquals("Q3"))
				{
					a.setINCENTIVEF(q3/2);
					a.setINCENTIVES(q3/2);
					a.setINCENTIVET(0);
				}
				else if(jcat.contentEquals("Q4"))
				{
					a.setINCENTIVEF(q4/2);
					a.setINCENTIVES(q4/2);
					a.setINCENTIVET(0);
				}
			}
			
			// incentives calculation for condition 3f
			
			else if(fauthor.contentEquals("Faculty") && (sauthor.contentEquals("Student") || sauthor.contentEquals("External")) && tauthor.contentEquals("Faculty"))
			{
				if(jcat.contentEquals("Q1"))
				{
					a.setINCENTIVEF(q1/2);
					a.setINCENTIVES(0);
					a.setINCENTIVET(q1/2);
				}
				else if(jcat.contentEquals("Q2"))
				{
					a.setINCENTIVEF(q2/2);
					a.setINCENTIVES(0);
					a.setINCENTIVET(q2/2);
				}
				else if(jcat.contentEquals("Q3"))
				{
					a.setINCENTIVEF(q3/2);
					a.setINCENTIVES(0);
					a.setINCENTIVET(q3/2);
				}
				else if(jcat.contentEquals("Q4"))
				{
					a.setINCENTIVEF(q4/2);
					a.setINCENTIVES(0);
					a.setINCENTIVET(q4/2);
				}
			}
			
			// incentives calculation for condition 3g
			
			else if(fauthor.contentEquals("Student") && sauthor.contentEquals("Faculty") && tauthor.contentEquals("Faculty"))
			{
				if(jcat.contentEquals("Q1"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(q1/2);
					a.setINCENTIVET(q1/2);
				}
				else if(jcat.contentEquals("Q2"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(q2/2);
					a.setINCENTIVET(q2/2);
				}
				else if(jcat.contentEquals("Q3"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(q3/2);
					a.setINCENTIVET(q3/2);
				}
				else if(jcat.contentEquals("Q4"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(q4/2);
					a.setINCENTIVET(q4/2);
				}
			}
			
			// incentive calculation for condition 3h
			
			else if(fauthor.contentEquals("External") && sauthor.contentEquals("Faculty") && tauthor.contentEquals("Faculty"))
			{
				if(jcat.contentEquals("Q1"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(q1/4);
					a.setINCENTIVET(q1/4);
				}
				else if(jcat.contentEquals("Q2"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(q2/4);
					a.setINCENTIVET(q2/4);
				}
				else if(jcat.contentEquals("Q3"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(q3/4);
					a.setINCENTIVET(q3/4);
				}
				else if(jcat.contentEquals("Q4"))
				{
					a.setINCENTIVEF(0);
					a.setINCENTIVES(q4/4);
					a.setINCENTIVET(q4/4);
				}
			}
			
			// incentive calculation for condition 3i
			
			else if(fauthor.contentEquals("Faculty") && sauthor.contentEquals("Faculty") && tauthor.contentEquals("Faculty"))
			{
				if(jcat.contentEquals("Q1"))
				{
					a.setINCENTIVEF(q1/2);
					a.setINCENTIVES(q1/4);
					a.setINCENTIVET(q1/4);
				}
				else if(jcat.contentEquals("Q2"))
				{
					a.setINCENTIVEF(q2/2);
					a.setINCENTIVES(q2/4);
					a.setINCENTIVET(q2/4);
				}
				else if(jcat.contentEquals("Q3"))
				{
					a.setINCENTIVEF(q3/2);
					a.setINCENTIVES(q3/4);
					a.setINCENTIVET(q3/4);
				}
				else if(jcat.contentEquals("Q4"))
				{
					a.setINCENTIVEF(q4/2);
					a.setINCENTIVES(q4/4);
					a.setINCENTIVET(q4/4);
				}
			} 
			
					
				try {
					applicationDAO.insertApplication(a);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Application Added Successfully with id="+a.getREFNO());
				String idd = a.getREFNO();
				request.setAttribute("refidd", idd);
				
				List<application> applications = applicationDAO.selectAll();
				request.setAttribute("Applications", applications);
				
				RequestDispatcher rd = getServletContext().getRequestDispatcher("/viewApplication.jsp");
				rd.forward(request, response);

		
		}
	}

}
