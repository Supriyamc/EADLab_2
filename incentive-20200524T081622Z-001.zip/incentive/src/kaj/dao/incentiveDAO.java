package kaj.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import kaj.model.incentive;


/**
 *  THIS IS FOR INCENTIVE AMOUNT. THIS CLASS WILL BE USED BY applicationServlet.java
 * @author chongthamkaj
 *
 */
public class incentiveDAO {
	
	// MySQL DATABASE INFORMATION FOR INCENTIVE AMOUNT
	
    private String jdbcURL = "jdbc:mysql://localhost:3306/rits_db?useSSL=false";
    private String jdbcUsername = "root";
    private String jdbcPassword = "wangkhei123";

    // SQL QUERIES FOR INSERTING, SELECTION BY ID AND SELECT ALL
    
    private static final String INSERT_USERS_SQL = "INSERT INTO amount" + "  (q1faculty, q1, q2, q3, q4) VALUES " +
        " (?, ?, ?, ?, ?);";

    private static final String SELECT_USER_BY_ID = "select id,q1faculty,q1,q2,q3,q4 from amount where id =?";
    private static final String SELECT_ALL_USERS = "select * from amount";
    private static final String DELETE_USERS_SQL = "delete from amount where id = ?;";
    private static final String UPDATE_USERS_SQL = "update amount set q1faculty = ?,q1= ?, q2 =?, q3=?, q4=? where id = ?;";

    public incentiveDAO() {}

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return connection;
    }

    public void insertUser(incentive user) throws SQLException {
        System.out.println(INSERT_USERS_SQL);
        // try-with-resource statement will auto close the connection.
        try (Connection connection = getConnection(); 
        	PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
            preparedStatement.setInt(1, user.getQ1faculty());
            preparedStatement.setInt(2, user.getQ1());
            preparedStatement.setInt(3, user.getQ2());
            preparedStatement.setInt(4, user.getQ3());
            preparedStatement.setInt(5, user.getQ4());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public incentive selectUser(int id) {
        incentive user = null;
        // Step 1: Establishing a Connection
        try (Connection connection = getConnection();
            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                int q1faculty = rs.getInt("q1faculty");
                int q1 = rs.getInt("q1");
                int q2 = rs.getInt("q2");
                int q3 = rs.getInt("q3");
                int q4 = rs.getInt("q4");
                
                user = new incentive(id, q1faculty, q1, q2, q3, q4);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return user;
    }

    public List < incentive > selectAllUsers() {

        // using try-with-resources to avoid closing resources (boiler plate code)
        List < incentive > users = new ArrayList < > ();
        // Step 1: Establishing a Connection
        try (Connection connection = getConnection();

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_USERS);) {
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                int id = rs.getInt("id");
                int q1faculty = rs.getInt("q1faculty");
                int q1 = rs.getInt("q1");
                int q2 = rs.getInt("q2");
                int q3 = rs.getInt("q3");
                int q4 = rs.getInt("q4");
                users.add(new incentive(id, q1faculty, q1, q2, q3, q4));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return users;
    }

    public boolean deleteUser(int id) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(DELETE_USERS_SQL);) {
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public boolean updateUser(incentive user) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(UPDATE_USERS_SQL);) {
            statement.setInt(1, user.getQ1faculty());
            statement.setInt(2, user.getQ1());
            statement.setInt(3, user.getQ2());
            statement.setInt(4, user.getQ3());
            statement.setInt(5, user.getQ4());
            statement.setInt(5, user.getId());

            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}