package kaj.model;

/**
 *  THIS IS FOR INCENTIVE AMOUNT NOT RELATED TO APPLICATION JOURNAL, THIS WILL BE USED IN applicationServlet.java
 * @author chongthamkaj
 *
 */

public class incentive {
    protected int id;
    protected int q1faculty;
    protected int q1;
    protected int q2;
    protected int q3;
    protected int q4;

    public incentive() {}

    public incentive(int q1faculty, int q1, int q2, int q3, int q4) {
        super();
        this.q1faculty = q1faculty;
        this.q1 = q1;
        this.q2 = q2;
        this.q3 = q3;
        this.q4 = q4;
    }

    public incentive(int id, int q1faculty, int q1, int q2, int q3, int q4) {
        super();
        this.id = id;
        this.q1faculty = q1faculty;
        this.q1 = q1;
        this.q2 = q2;
        this.q3 = q3;
        this.q4 = q4;
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getQ1faculty() {
		return q1faculty;
	}

	public void setQ1faculty(int q1faculty) {
		this.q1faculty = q1faculty;
	}

	public int getQ1() {
		return q1;
	}

	public void setQ1(int q1) {
		this.q1 = q1;
	}

	public int getQ2() {
		return q2;
	}

	public void setQ2(int q2) {
		this.q2 = q2;
	}

	public int getQ3() {
		return q3;
	}

	public void setQ3(int q3) {
		this.q3 = q3;
	}

	public int getQ4() {
		return q4;
	}

	public void setQ4(int q4) {
		this.q4 = q4;
	}

   
}