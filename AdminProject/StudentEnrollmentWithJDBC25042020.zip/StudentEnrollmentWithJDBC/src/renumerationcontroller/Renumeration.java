package renumerationcontroller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.*;
import leavemanagementcontroller.DatabaseConnection;

/**
 * Servlet implementation class Renumeration
 */
@WebServlet("/Renumeration")
public class Renumeration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	 String counter = "";
	 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {						
	 	 		
	 		System.out.println("java");
	 		try{  
	 			Connection con = DatabaseConnection.initializeDatabase(); 
	 			 
	 			Statement stmt=con.createStatement();
	 			ResultSet rs = null;
	 			//ResultSet rs = stmt.executeQuery("");
	 			
	 				 rs=stmt.executeQuery("select * from renumeration_configuration");
	 				 System.out.println("insid");
	 			
	 				 JSONObject jsonObject = new JSONObject();
	 					JSONArray array = new JSONArray();
	 					while(rs.next()) {
	 						
	 					JSONObject record = new JSONObject();
	 					record.put("QPSetting_BE", rs.getString("QPSetting_BE"));
	 					record.put("QPSetting_Mtech", rs.getString("QPSetting_Mtech"));
	 					record.put("QPSetting_MCA", rs.getString("QPSetting_MCA"));
	 					record.put("QPSetting_MBA", rs.getString("QPSetting_MBA"));
	 					record.put("SSSetting_BE", rs.getString("SSSetting_BE"));
	 					record.put("SSSetting_Mtech", rs.getString("SSSetting_Mtech"));
	 					record.put("SSSetting_MCA", rs.getString("SSSetting_MCA"));
	 					record.put("SSSetting_MBA", rs.getString("SSSetting_MBA"));
	 					record.put("VMSetting_BE", rs.getString("VMSetting_BE"));
	 					record.put("VMSetting_Mtech", rs.getString("VMSetting_Mtech"));
	 					record.put("VMSetting_MCA", rs.getString("VMSetting_MCA"));
	 					record.put("VMSetting_MBA", rs.getString("VMSetting_MBA"));
	 					record.put("GPsetting_BE", rs.getString("GPsetting_BE"));
	 					record.put("GPsetting_Mtech", rs.getString("GPsetting_Mtech"));
	 					record.put("GPsetting_MCA", rs.getString("GPsetting_MCA"));
	 					record.put("GPsetting_MBA", rs.getString("GPsetting_MBA"));
	 					record.put("PESetting_BE", rs.getString("PESetting_BE"));
	 					record.put("PESetting_MBA", rs.getString("PESetting_MBA"));
	 					record.put("PESetting_Mtech", rs.getString("PESetting_Mtech"));
	 					record.put("PESetting_MCA", rs.getString("PESetting_MCA"));	 					
	 					record.put("BOSSetting_BE", rs.getString("BOSSetting_BE"));
	 					record.put("BOSSetting_Mtech", rs.getString("BOSSetting_Mtech"));
	 					record.put("BOSSetting_MCA", rs.getString("BOSSetting_MCA"));
	 					record.put("BOSSetting_MBA", rs.getString("BOSSetting_MBA"));
	 					record.put("BOESetting_BE", rs.getString("BOESetting_BE"));
	 					record.put("BOESetting_Mtech", rs.getString("BOESetting_Mtech"));
	 					record.put("BOESetting_MCA", rs.getString("BOESetting_MCA"));
	 					record.put("BOESetting_MBA", rs.getString("BOESetting_MBA"));
	 					record.put("PVVSetting_BE", rs.getString("PVVSetting_BE"));
	 					record.put("PVVSetting_Mtech", rs.getString("PVVSetting_Mtech"));
	 					record.put("PVVSetting_MCA", rs.getString("PVVSetting_MCA"));
	 					record.put("PVVSetting_MBA", rs.getString("PVVSetting_MBA"));
	 					record.put("PRESetting_BE", rs.getString("PRESetting_BE"));
	 					record.put("PRESetting_MBA", rs.getString("PRESetting_MBA"));
	 					record.put("PRESetting_Mtech", rs.getString("PRESetting_Mtech"));
	 					record.put("PRESetting_MCA", rs.getString("PRESetting_MCA"));	 	
	 					record.put("SDSetting_BE", rs.getString("SDSetting_BE"));
	 					record.put("SDSetting_Mtech", rs.getString("SDSetting_Mtech"));
	 					record.put("SDSetting_MCA", rs.getString("SDSetting_MCA"));
	 					record.put("SDSetting_MBA", rs.getString("SDSetting_MBA"));
	 					
	 				   array.put(record);	 				   
	 				    System.out.println(array);
	 					
	 				}	
	 				 	String str = array.toString();
	 					counter = str;
	 					
	 					System.out.println(str);
	 					response.getWriter().append(str); 
	 			        con.close(); 
	 		}	 		 				
	 		catch(Exception e){ System.out.println(e);}  
		 	} 
	 
	     protected void doPost(HttpServletRequest request,  
	    		 HttpServletResponse response) 
	         throws ServletException, IOException 
	         
	     { 
	         try { 
	   
	             // Initialize the database 
	             Connection con = DatabaseConnection.initializeDatabase(); 
	    	 	System.out.println(counter);		
	 			
	    	 	PreparedStatement stmt = con 
	 	                    .prepareStatement("insert into renumeration_configuration(QPSetting_BE,QPSetting_Mtech,QPSetting_MCA,QPSetting_MBA,SSSetting_BE,SSSetting_Mtech,SSSetting_MCA,SSSetting_MBA,VMSetting_BE,VMSetting_Mtech,VMSetting_MCA,VMSetting_MBA,GPsetting_BE,GPsetting_Mtech,GPsetting_MCA,GPsetting_MBA,PESetting_BE,PESetting_Mtech,PESetting_MCA,PESetting_MBA,BOSSetting_BE,BOSSetting_Mtech,BOSSetting_MCA,BOSSetting_MBA,BOESetting_BE,BOESetting_Mtech,BOESetting_MCA,BOESetting_MBA,PVVSetting_BE,PVVSetting_Mtech,PVVSetting_MCA,PVVSetting_MBA,PRESetting_BE,PRESetting_MBA,PRESetting_Mtech,PRESetting_MCA,SDSetting_BE,SDSetting_Mtech,SDSetting_MCA,SDSetting_MBA) values (?, ?, ?, ?, ?,?, ?, ?, ?, ?,?, ?, ?, ?, ?,?, ?, ?, ?, ?,?, ?, ?, ?, ?,?, ?, ?, ?, ?,?, ?, ?, ?, ?,?,?,?,?,?)");

	 	  
	 	            // For the first parameter, 
	 	            // get the data using request object 
	 	            // sets the data to st pointer 
	 				stmt.setString(1, request.getParameter("QPSetting_BE"));	 	  
	 	         	stmt.setString(2, request.getParameter("QPSetting_Mtech")); 	 	            
	 				stmt.setString(3, request.getParameter("QPSetting_MCA")); 
	 				stmt.setString(4, request.getParameter("QPSetting_MBA")); 
	 				stmt.setString(5, request.getParameter("SSSetting_BE")); 
	 				stmt.setString(6, request.getParameter("SSSetting_Mtech")); 
	 				stmt.setString(7, request.getParameter("SSSetting_MCA")); 
	 				stmt.setString(8, request.getParameter("SSSetting_MBA")); 
	 				stmt.setString(9, request.getParameter("VMSetting_BE")); 
	 				stmt.setString(10, request.getParameter("VMSetting_Mtech")); 
	 				stmt.setString(11, request.getParameter("VMSetting_MCA")); 
	 				stmt.setString(12, request.getParameter("VMSetting_MBA")); 
	 				stmt.setString(13, request.getParameter("GPsetting_BE")); 
	 				stmt.setString(14, request.getParameter("GPsetting_Mtech")); 
	 				stmt.setString(15, request.getParameter("GPsetting_MCA")); 
	 				stmt.setString(16, request.getParameter("GPsetting_MBA")); 
	 				stmt.setString(17, request.getParameter("PESetting_BE")); 
	 				stmt.setString(18, request.getParameter("PESetting_Mtech")); 
	 				stmt.setString(19, request.getParameter("PESetting_MCA")); 
	 				stmt.setString(20, request.getParameter("PESetting_MBA")); 
	 				stmt.setString(21, request.getParameter("BOSSetting_BE")); 
	 				stmt.setString(22, request.getParameter("BOSSetting_Mtech")); 
	 				stmt.setString(23, request.getParameter("BOSSetting_MCA")); 
	 				stmt.setString(24, request.getParameter("BOSSetting_MBA")); 
	 				stmt.setString(25, request.getParameter("BOESetting_BE")); 
	 				stmt.setString(26, request.getParameter("BOESetting_Mtech")); 
	 				stmt.setString(27, request.getParameter("BOESetting_MCA")); 
	 				stmt.setString(28, request.getParameter("BOESetting_MBA")); 
	 				stmt.setString(29, request.getParameter("PVVSetting_BE")); 
	 				stmt.setString(30, request.getParameter("PVVSetting_Mtech")); 
	 				stmt.setString(31, request.getParameter("PVVSetting_MCA")); 
	 				stmt.setString(32, request.getParameter("PVVSetting_MBA"));
	 				stmt.setString(33, request.getParameter("PRESetting_BE")); 
	 				stmt.setString(34, request.getParameter("PRESetting_Mtech")); 
	 				stmt.setString(35, request.getParameter("PRESetting_MCA")); 
	 				stmt.setString(36, request.getParameter("PRESetting_MBA")); 
	 				stmt.setString(37, request.getParameter("SDSetting_BE")); 
	 				stmt.setString(38, request.getParameter("SDSetting_Mtech")); 
	 				stmt.setString(39, request.getParameter("SDSetting_MCA")); 
	 				stmt.setString(40, request.getParameter("SDSetting_MBA")); 
	 	  
	 	            // Execute the insert command using executeUpdate() 	 	           
	 				stmt.executeUpdate();		
	 						
	 	           stmt.close(); 
	 	           con.close();	          
	 	           response.sendRedirect("content/renumeration.jsp");
	             
	         } 
	         catch (Exception e) { 
	             e.printStackTrace(); 
	         } 
	         
	     } 
	     
	 } 
