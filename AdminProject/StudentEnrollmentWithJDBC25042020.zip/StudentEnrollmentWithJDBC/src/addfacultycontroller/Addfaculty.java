package addfacultycontroller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import leavemanagementcontroller.DatabaseConnection;

/**
 * Servlet implementation class Addfaculty
 */
@WebServlet("/Addfaculty")
public class Addfaculty extends HttpServlet { 
    private static final long serialVersionUID = 1L; 
  
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		//fetching the username and password from the user input with names "username" and "password" which is present in the login.jsp page
		
		
		
		System.out.println("java");
}
    
    protected void doPost(HttpServletRequest request,  
HttpServletResponse response) 
        throws ServletException, IOException 
        
    { 
        try { 
  
            // Initialize the database 
            Connection con = DatabaseConnection.initializeDatabase(); 
   
            // Create a SQL query to insert data into demo table 
            // demo table consists of two columns, so two '?' is used 
            
          
				
				PreparedStatement stmt = con 
	                    .prepareStatement("insert into faculty(faculty_id,faculty_name,password,department,gender,dateofbirth,designation,contact_number,dateofjoining,email,natureofappt) values (?,?,?,?,?,?,?,?,?,?,?)");

				stmt.setString(1, request.getParameter("faculty_id"));  
	        	stmt.setString(2, request.getParameter("faculty_name")); 
	        	stmt.setString(3, request.getParameter("password")); 
				stmt.setString(4, request.getParameter("department")); 
				stmt.setString(5, request.getParameter("gender")); 
				stmt.setString(6, request.getParameter("dateofbirth")); 
				stmt.setString(7, request.getParameter("designation")); 
				stmt.setString(8, request.getParameter("contact_number")); 
				stmt.setString(9, request.getParameter("dateofjoining")); 				
				stmt.setString(10, request.getParameter("email")); 
				stmt.setString(11, request.getParameter("natureofappt")); 
				
	  
	            // Execute the insert command using executeUpdate() 
	            // to make changes in database 
				stmt.executeUpdate();
				
				//response.sendRedirect("leave.jsp");
			
            
            

            
            // For the first parameter, 
            // get the data using request object 
            // sets the data to st pointer 
            //st.setString(1, request.getParameter("CL")); 
  
            // Same for second parameter 
           // st.setString(2, request.getParameter("EL")); 
            
           // st.setString(3, request.getParameter("RH")); 
           // st.setString(4, request.getParameter("ML")); 
          //  st.setString(5, request.getParameter("CCL")); 
  
            // Execute the insert command using executeUpdate() 
            // to make changes in database 
            
  
            // Close all the connections 
            
            con.close(); 
  
            // Get a writer pointer  
            // to display the successful result 
            //PrintWriter out = response.getWriter(); 
            response.sendRedirect("content/faculty.jsp");
            
        } 
        catch (Exception e) { 
            e.printStackTrace(); 
        } 
        
    } 
    
}
