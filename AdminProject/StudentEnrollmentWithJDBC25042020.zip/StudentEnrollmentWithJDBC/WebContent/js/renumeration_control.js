$(document).ready(function(){
	//alert("leave management");
	$.get("../Renumeration" ,  function(result){
		var js_arr = JSON.parse(result);
		//alert(js_arr[0].QPSetting_BE);
		$("#QPSetting_BE").val(js_arr[0].QPSetting_BE);
		$("#QPSetting_Mtech").val(js_arr[0].QPSetting_Mtech);
		$("#QPSetting_MCA").val(js_arr[0].QPSetting_MCA);
		$("#QPSetting_MBA").val(js_arr[0].QPSetting_MBA);
		$("#SSSetting_BE").val(js_arr[0].SSSetting_BE);
		$("#SSSetting_Mtech").val(js_arr[0].SSSetting_Mtech);
		$("#SSSetting_MCA").val(js_arr[0].SSSetting_MCA);
		$("#SSSetting_MBA").val(js_arr[0].SSSetting_MBA);
		$("#VMSetting_BE").val(js_arr[0].VMSetting_BE);
		$("#VMSetting_Mtech").val(js_arr[0].VMSetting_Mtech);
		$("#VMSetting_MCA").val(js_arr[0].VMSetting_MCA);
		$("#VMSetting_MBA").val(js_arr[0].VMSetting_MBA);
		$("#GPsetting_BE").val(js_arr[0].GPsetting_BE);
		$("#GPsetting_Mtech").val(js_arr[0].GPsetting_Mtech);
		$("#GPsetting_MCA").val(js_arr[0].GPsetting_MCA);
		$("#GPsetting_MBA").val(js_arr[0].GPsetting_MBA);
		$("#PESetting_BE").val(js_arr[0].PESetting_BE);
		$("#PESetting_Mtech").val(js_arr[0].PESetting_Mtech);
		$("#PESetting_MCA").val(js_arr[0].PESetting_MCA);
		$("#PESetting_MBA").val(js_arr[0].PESetting_MBA);
		$("#BOSSetting_BE").val(js_arr[0].BOSSetting_BE);
		$("#BOSSetting_Mtech").val(js_arr[0].BOSSetting_Mtech);
		$("#BOSSetting_MCA").val(js_arr[0].BOSSetting_MCA);
		$("#BOSSetting_MBA").val(js_arr[0].BOSSetting_MBA);
		$("#BOESetting_BE").val(js_arr[0].BOESetting_BE);
		$("#BOESetting_Mtech").val(js_arr[0].BOESetting_Mtech);
		$("#BOESetting_MCA").val(js_arr[0].BOESetting_MCA);
		$("#BOESetting_MBA").val(js_arr[0].BOESetting_MBA);
		$("#PVVSetting_BE").val(js_arr[0].PVVSetting_BE);
		$("#PVVSetting_Mtech").val(js_arr[0].PVVSetting_Mtech);
		$("#PVVSetting_MCA").val(js_arr[0].PVVSetting_MCA);
		$("#PVVSetting_MBA").val(js_arr[0].PVVSetting_MBA);
		$("#PRESetting_BE").val(js_arr[0].PRESetting_BE);
		$("#PRESetting_Mtech").val(js_arr[0].PRESetting_Mtech);
		$("#PRESetting_MCA").val(js_arr[0].PRESetting_MCA);
		$("#PRESetting_MBA").val(js_arr[0].PRESetting_MBA);
		$("#SDSetting_BE").val(js_arr[0].SDSetting_BE);
		$("#SDSetting_Mtech").val(js_arr[0].SDSetting_Mtech);
		$("#SDSetting_MCA").val(js_arr[0].SDSetting_MCA);
		$("#SDSetting_MBA").val(js_arr[0].SDSetting_MBA);
		
		
	});
	
	
});