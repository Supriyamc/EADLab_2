package leavemanagementcontroller;

import java.io.IOException; 
import java.io.PrintWriter; 
import java.sql.Connection; 
import java.sql.PreparedStatement; 
  
import javax.servlet.ServletException; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse; 
  
// Import Database Connection Class file 
import leavemanagementcontroller.DatabaseConnection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.*;
  
// Servlet Name 
@WebServlet("/leavemanagement") 
public class leavemanagement extends HttpServlet { 
    private static final long serialVersionUID = 1L; 
  String counter = "";
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		//fetching the username and password from the user input with names "username" and "password" which is present in the login.jsp page
		
		
		
		System.out.println("java");
		try{  
			Connection con = DatabaseConnection.initializeDatabase();  
			//here rits_db is database name, rits is username and password 
			Statement stmt=con.createStatement();
			ResultSet rs = null;
			
			//ResultSet rs = stmt.executeQuery("");
			
				 rs=stmt.executeQuery("select * from leavemanagement");
				 System.out.println("insid");
			
				 JSONObject jsonObject = new JSONObject();
					JSONArray array = new JSONArray();
					while(rs.next()) {
						
					JSONObject record = new JSONObject();
					record.put("CL", rs.getString("CL"));
					record.put("EL", rs.getString("EL"));
					record.put("RH", rs.getString("RH"));
					record.put("ML", rs.getString("ML"));
					record.put("CCL", rs.getString("CCL"));
					
				   array.put(record);
				   
				  System.out.println(array);
					
				}	

			
			
			
					String str = array.toString();
					counter = str;
					
					System.out.println(str);
					response.getWriter().append(str); 
			 con.close(); 
			
		}					
				
		
			//response.getWriter().append(str);			
			 
		
			
			
		
		
		
		
		
			catch(Exception e){ System.out.println(e);}  
		
		
	}

    
    
    protected void doPost(HttpServletRequest request,  
HttpServletResponse response) 
        throws ServletException, IOException 
        
    { 
        try { 
  
            // Initialize the database 
            Connection con = DatabaseConnection.initializeDatabase(); 
   
            // Create a SQL query to insert data into demo table 
            // demo table consists of two columns, so two '?' is used 
            
            if(counter.equals("[]")) {
				System.out.println(counter);
				
				PreparedStatement stmt = con 
	                    .prepareStatement("insert into leavemanagement(CL,EL,RH,ML,CCL) values (?, ?, ?, ?, ?)");

	  
	            // For the first parameter, 
	            // get the data using request object 
	            // sets the data to st pointer 
				stmt.setString(1, request.getParameter("CL")); 
	  
	            // Same for second parameter 
				stmt.setString(2, request.getParameter("EL")); 
	            
				stmt.setString(3, request.getParameter("RH")); 
				stmt.setString(4, request.getParameter("ML")); 
				stmt.setString(5, request.getParameter("CCL")); 
	  
	            // Execute the insert command using executeUpdate() 
	            // to make changes in database 
				stmt.executeUpdate();
				//response.sendRedirect("leave.jsp");
			}
            else {
            String sqlUpdate = "UPDATE leavemanagement SET CL = ? , EL = ?,RH = ?, ML = ?, CCL = ? ";
                   
            PreparedStatement st = con 
                    .prepareStatement(sqlUpdate);
            
            
            st.setString(1, request.getParameter("CL")); 
            st.setString(2, request.getParameter("EL")); 
            st.setString(3, request.getParameter("RH"));
            st.setString(4, request.getParameter("ML"));
            st.setString(5, request.getParameter("CCL"));
            
            st.executeUpdate();
            

            
            // For the first parameter, 
            // get the data using request object 
            // sets the data to st pointer 
            //st.setString(1, request.getParameter("CL")); 
  
            // Same for second parameter 
           // st.setString(2, request.getParameter("EL")); 
            
           // st.setString(3, request.getParameter("RH")); 
           // st.setString(4, request.getParameter("ML")); 
          //  st.setString(5, request.getParameter("CCL")); 
  
            // Execute the insert command using executeUpdate() 
            // to make changes in database 
            
  
            // Close all the connections 
            st.close(); 
            con.close(); 
  
            // Get a writer pointer  
            // to display the successful result 
            //PrintWriter out = response.getWriter(); 
            response.sendRedirect("JSP/leave.jsp");
            
        } }
        catch (Exception e) { 
            e.printStackTrace(); 
        } 
        
    } 
    
} 