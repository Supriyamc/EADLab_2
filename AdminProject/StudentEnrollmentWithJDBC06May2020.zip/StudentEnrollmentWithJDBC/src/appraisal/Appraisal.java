package appraisal;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.*;

import leavemanagementcontroller.DatabaseConnection;

/**
 * Servlet implementation class Appraisal
 */
@WebServlet("/Appraisal")
public class Appraisal extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String counter = "";   
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {						
	 	 		
	 		System.out.println("java");
	 		try{  
	 			Connection con = DatabaseConnection.initializeDatabase(); 
	 			 
	 			Statement stmt=con.createStatement();
	 			ResultSet rs = null;
	 			//ResultSet rs = stmt.executeQuery("");
	 			
	 				 rs=stmt.executeQuery("select * from appraisal");
	 				 System.out.println("inside");
	 			
	 				 JSONObject jsonObject = new JSONObject();
	 					JSONArray array = new JSONArray();
	 					while(rs.next()) {
	 						
	 					JSONObject record = new JSONObject();
	 					record.put("As_Teach", rs.getString("As_Teach"));
	 					record.put("As_Res", rs.getString("As_Res"));
	 					record.put("As_ser", rs.getString("As_ser"));
	 					record.put("Asso_Teach", rs.getString("Asso_Teach"));
	 					record.put("Asso_Res", rs.getString("Asso_Res"));
	 					record.put("Asso_Ser", rs.getString("Asso_Ser"));
	 					record.put("Pro_Teach", rs.getString("Pro_Teach"));
	 					record.put("Pro_Res", rs.getString("Pro_Res"));
	 					record.put("Pro_Ser", rs.getString("Pro_Ser"));
	 					record.put("Prohead_Teach", rs.getString("Prohead_Teach"));
	 					record.put("Prohead_Res", rs.getString("Prohead_Res"));
	 					record.put("Prohead_Ser", rs.getString("Prohead_Ser"));
	 					record.put("fci1", rs.getString("fci1"));
	 					record.put("fci2", rs.getString("fci2"));
	 					record.put("fci3", rs.getString("fci3"));
	 					record.put("fci4", rs.getString("fci4"));
	 					record.put("fci5", rs.getString("fci5"));
	 					record.put("nirf1", rs.getString("nirf1"));
	 					record.put("index1", rs.getString("index1"));
	 					record.put("index2", rs.getString("index2"));	 					
	 					record.put("index3", rs.getString("index3"));
	 					record.put("jou", rs.getString("jou"));
	 					record.put("b1", rs.getString("b1"));
	 					record.put("b2", rs.getString("b2"));
	 					record.put("dis", rs.getString("dis"));
	 					record.put("pat", rs.getString("pat"));
	 					record.put("rUG", rs.getString("rUG"));
	 					record.put("rPG", rs.getString("rPG"));
	 					record.put("rPHD", rs.getString("rPHD"));
	 					record.put("fp1", rs.getString("fp1"));
	 					record.put("fp2", rs.getString("fp2"));
	 					record.put("fp2", rs.getString("fp2"));
	 					record.put("fp3", rs.getString("fp3"));
	 					record.put("fp4", rs.getString("fp4"));
	 					record.put("fp5", rs.getString("fp5"));
	 					record.put("cp1", rs.getString("cp1"));
	 					record.put("cp2", rs.getString("cp2"));
	 					record.put("cp3", rs.getString("cp3"));	 	
	 					record.put("cp4", rs.getString("cp4"));
	 					record.put("cp5", rs.getString("cp5"));
	 					record.put("chair", rs.getString("chair"));
	 					record.put("cfdp1", rs.getString("cfdp1"));
	 					record.put("cfdp2", rs.getString("cfdp2"));
	 					record.put("talk", rs.getString("talk"));
	 					record.put("cfdp2", rs.getString("cfdp2"));
	 					record.put("eveo", rs.getString("eveo"));
	 					record.put("invi", rs.getString("invi"));
	 					record.put("ind", rs.getString("ind"));
	 					record.put("nba1", rs.getString("nba1"));
	 					record.put("nba2", rs.getString("nba2"));
	 					record.put("OS1", rs.getString("OS1"));
	 					record.put("award", rs.getString("award"));
	 					
	 				   array.put(record);	 				   
	 				    System.out.println(array);
	 					
	 				}	
	 				 	String str = array.toString();
	 					counter = str;
	 					
	 					System.out.println(str);
	 					response.getWriter().append(str); 
	 			        con.close(); 
	 		}	 		 				
	 		catch(Exception e){ System.out.println(e);}  
		 	} 
	 
	     protected void doPost(HttpServletRequest request,  
	    		 HttpServletResponse response) 
	         throws ServletException, IOException 
	         
	     { 
	         try { 
	   
	             // Initialize the database 
	            Connection con = DatabaseConnection.initializeDatabase(); 
	            if(counter.equals("[]")) {
	    	 	System.out.println(counter);		
	 			
	    	 	PreparedStatement stmt = con 
	 	                    .prepareStatement("insert into appraisal(As_Teach,As_Res,As_ser,Asso_Teach,Asso_Res,Asso_Ser,Pro_Teach,Pro_Res,Pro_Ser,Prohead_Teach,Prohead_Res,Prohead_Ser,fci1,fci2,fci3,fci4,fci5,nirf1,index1,index2,index3,jou,b1,b2,dis,pat,rUG,rPG,rPHD,fp1,fp2,fp3,fp4,fp5,cp1,cp2,cp3,cp4,cp5,chair,cfdp1,cfdp2,talk,eveo,invi,ind,nba1,nba2,OS1,award) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

	 	  
	 	            // For the first parameter, 
	 	            // get the data using request object 
	 	            // sets the data to st pointer 
	 				stmt.setString(1, request.getParameter("As_Teach"));	 	  
	 	         	stmt.setString(2, request.getParameter("As_Res")); 	 	            
	 				stmt.setString(3, request.getParameter("As_ser")); 
	 				stmt.setString(4, request.getParameter("Asso_Teach")); 
	 				stmt.setString(5, request.getParameter("Asso_Res")); 
	 				stmt.setString(6, request.getParameter("Asso_Ser")); 
	 				stmt.setString(7, request.getParameter("Pro_Teach")); 
	 				stmt.setString(8, request.getParameter("Pro_Res")); 
	 				stmt.setString(9, request.getParameter("Pro_Ser")); 
	 				stmt.setString(10, request.getParameter("Prohead_Teach")); 
	 				stmt.setString(11, request.getParameter("Prohead_Res")); 
	 				stmt.setString(12, request.getParameter("Prohead_Ser")); 
	 				stmt.setString(13, request.getParameter("fci1")); 
	 				stmt.setString(14, request.getParameter("fci2")); 
	 				stmt.setString(15, request.getParameter("fci3")); 
	 				stmt.setString(16, request.getParameter("fci4")); 
	 				stmt.setString(17, request.getParameter("fci5")); 
	 				stmt.setString(18, request.getParameter("nirf1")); 
	 				stmt.setString(19, request.getParameter("index1")); 
	 				stmt.setString(20, request.getParameter("index2")); 
	 				stmt.setString(21, request.getParameter("index3")); 
	 				stmt.setString(22, request.getParameter("jou")); 
	 				stmt.setString(23, request.getParameter("b1")); 
	 				stmt.setString(24, request.getParameter("b2")); 
	 				stmt.setString(25, request.getParameter("dis")); 
	 				stmt.setString(26, request.getParameter("pat")); 
	 				stmt.setString(27, request.getParameter("rUG")); 
	 				stmt.setString(28, request.getParameter("rPG")); 
	 				stmt.setString(29, request.getParameter("rPHD")); 
	 				stmt.setString(30, request.getParameter("fp1")); 
	 				stmt.setString(31, request.getParameter("fp2")); 
	 				stmt.setString(32, request.getParameter("fp3"));
	 				stmt.setString(33, request.getParameter("fp4")); 
	 				stmt.setString(34, request.getParameter("fp5"));
	 				stmt.setString(35, request.getParameter("cp1")); 
	 				stmt.setString(36, request.getParameter("cp2")); 
	 				stmt.setString(37, request.getParameter("cp3"));
	 				stmt.setString(38, request.getParameter("cp4")); 
	 				stmt.setString(39, request.getParameter("cp5")); 
	 				stmt.setString(40, request.getParameter("chair")); 
	 				stmt.setString(41, request.getParameter("cfdp1")); 
	 				stmt.setString(42, request.getParameter("cfdp2")); 
	 				stmt.setString(43, request.getParameter("talk")); 
	 				stmt.setString(44, request.getParameter("eveo")); 
	 				stmt.setString(45, request.getParameter("invi")); 
	 				stmt.setString(46, request.getParameter("ind")); 
	 				stmt.setString(47, request.getParameter("nba1")); 
	 				stmt.setString(48, request.getParameter("nba2")); 
	 				stmt.setString(49, request.getParameter("OS1")); 
	 				stmt.setString(50, request.getParameter("award")); 
	 	  
	 	            // Execute the insert command using executeUpdate() 	 	           
	 				stmt.executeUpdate();
	 				
	            }
	            else {
	            	String sqlUpdate = "UPDATE appraisal SET As_Teach= ? ,As_Res= ? ,As_ser= ?,Asso_Teach=?,Asso_Res=?,Asso_Ser=?,Pro_Teach=?,Pro_Res=?,Pro_Ser=?,Prohead_Teach=?,Prohead_Res=?,Prohead_Ser=?,fci1=?,fci2=?,fci3=?,fci4=?,fci5=?,nirf1=?,index1=?,index2=?,index3=?,jou=?,b1=?,b2=?,dis=?,pat=?,rUG=?,rPG=?,rPHD=?,fp1=?,fp2=?,fp3=?,fp4=?,fp5=?,cp1=?,cp2=?,cp3=?,cp4=?,cp5=?,chair=?,cfdp1=?,cfdp2=?,talk=?,eveo=?,invi=?,ind=?,nba1=?,nba2=?,OS1=?,award=?";
                
	            PreparedStatement st = con 
	                    .prepareStatement(sqlUpdate);
	            
	            
	            st.setString(1, request.getParameter("As_Teach"));		            
 	         	st.setString(2, request.getParameter("As_Res")); 	 	            
 				st.setString(3, request.getParameter("As_ser")); 
 				st.setString(4, request.getParameter("Asso_Teach")); 
 				st.setString(5, request.getParameter("Asso_Res")); 
 				st.setString(6, request.getParameter("Asso_Ser")); 
 				st.setString(7, request.getParameter("Pro_Teach")); 
 				st.setString(8, request.getParameter("Pro_Res")); 
 				st.setString(9, request.getParameter("Pro_Ser")); 
 				st.setString(10, request.getParameter("Prohead_Teach")); 
 				st.setString(11, request.getParameter("Prohead_Res")); 
 				st.setString(12, request.getParameter("Prohead_Ser")); 
 				st.setString(13, request.getParameter("fci1")); 
 				st.setString(14, request.getParameter("fci2")); 
 				st.setString(15, request.getParameter("fci3")); 
 				st.setString(16, request.getParameter("fci4")); 
 				st.setString(17, request.getParameter("fci5")); 
 				st.setString(18, request.getParameter("nirf1")); 
 				st.setString(19, request.getParameter("index1")); 
 				st.setString(20, request.getParameter("index2")); 
 				st.setString(21, request.getParameter("index3")); 
 				st.setString(22, request.getParameter("jou")); 
 				st.setString(23, request.getParameter("b1")); 
 				st.setString(24, request.getParameter("b2")); 
 				st.setString(25, request.getParameter("dis")); 
 				st.setString(26, request.getParameter("pat")); 
 				st.setString(27, request.getParameter("rUG")); 
 				st.setString(28, request.getParameter("rPG")); 
 				st.setString(29, request.getParameter("rPHD")); 
 				st.setString(30, request.getParameter("fp1")); 
 				st.setString(31, request.getParameter("fp2")); 
 				st.setString(32, request.getParameter("fp3"));
 				st.setString(33, request.getParameter("fp4")); 
 				st.setString(34, request.getParameter("fp5"));
 				st.setString(35, request.getParameter("cp1")); 
 				st.setString(36, request.getParameter("cp2")); 
 				st.setString(37, request.getParameter("cp3"));
 				st.setString(38, request.getParameter("cp4")); 
 				st.setString(39, request.getParameter("cp5")); 
 				st.setString(40, request.getParameter("chair")); 
 				st.setString(41, request.getParameter("cfdp1")); 
 				st.setString(42, request.getParameter("cfdp2")); 
 				st.setString(43, request.getParameter("talk")); 
 				st.setString(44, request.getParameter("eveo")); 
 				st.setString(45, request.getParameter("invi")); 
 				st.setString(46, request.getParameter("ind")); 
 				st.setString(47, request.getParameter("nba1")); 
 				st.setString(48, request.getParameter("nba2")); 
 				st.setString(49, request.getParameter("OS1")); 
 				st.setString(50, request.getParameter("award")); 
	            
	            st.executeUpdate();
	 						
	 	           st.close(); 
	 	           con.close();	          
	 	           response.sendRedirect("JSP/appraisal.jsp");
	             
	         }}
	         catch (Exception e) { 
	             e.printStackTrace(); 
	         } 
	         
	     } 
	     
	 } 
