package addfacultycontroller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.github.elizabetht.util.DbUtil;

import leavemanagementcontroller.DatabaseConnection;

/**
 * Servlet implementation class Addfaculty
 */
@WebServlet("/Addfaculty")
public class Addfaculty extends HttpServlet { 
private Connection dbConnection;
	
	public Addfaculty() {
		dbConnection = DbUtil.getConnection();
	}
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String faculty_id =  request.getParameter("faculty_id");
		String faculty_name =  request.getParameter("faculty_name");
		String password =  request.getParameter("password");
		String department =  request.getParameter("department");
		String gender =  request.getParameter("gender");
		String dateofbirth =  request.getParameter("dateofbirth");
		String designation =  request.getParameter("designation");
		String contact_number =  request.getParameter("contact_number");
		String dateofjoining =  request.getParameter("dateofjoining");
		String email =  request.getParameter("email");
		String natureofappt =  request.getParameter("natureofappt");
		String role =  request.getParameter("role");
		//String faculty_id =  request.getParameter("faculty_id");
      
     
             try {        	   
         PreparedStatement stmt = dbConnection.prepareStatement("insert into faculty(faculty_id,faculty_name,password,department,gender,dateofbirth,designation,contact_number,dateofjoining,email,natureofappt,role) values (?,?,?,?,?,?,?,?,?,?,?,?)");

				stmt.setString(1,faculty_id);  
	        	stmt.setString(2,faculty_name); 
	        	stmt.setString(3, password);
				stmt.setString(4, department);
				stmt.setString(5,gender); 
				stmt.setString(6,dateofbirth); 
				stmt.setString(7,designation); 
				stmt.setString(8,contact_number); 
				stmt.setString(9,dateofjoining); 				
				stmt.setString(10,email); 
				stmt.setString(11,natureofappt);
				stmt.setString(12,"faculty");
				
	  
				stmt.executeUpdate();
				
				response.sendRedirect("JSP/faculty.jsp");
        	   } catch (SQLException e) {
       			e.printStackTrace();
       		}
     }
}  	     	
           	

