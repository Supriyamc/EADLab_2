Hello,

1. Please copy java files C:\Users\kavitha\Desktop\To Github Upload\StudentEnrollmentWithJDBC\src\addfacultycontroller. 
2. Please copy, JSP files,Index file and JS files from C:\Users\kavitha\Desktop\To Github Upload\StudentEnrollmentWithJDBC\WebContent folder