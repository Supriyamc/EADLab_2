package addfacultycontroller;
import java.io.BufferedReader;
import java.io.IOException; 
import java.io.PrintWriter; 
import java.sql.Connection; 
import java.sql.PreparedStatement; 
  
import javax.servlet.ServletException; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse; 
  
// Import Database Connection Class file 
//import leavemanagementcontroller.DatabaseConnection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.*;
import leavemanagementcontroller.DatabaseConnection;

/**
 * Servlet implementation class Changepassword
 */
@WebServlet("/delete_faculty")
public class delete_faculty extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public delete_faculty() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		StringBuilder sb = new StringBuilder();
        BufferedReader br = request.getReader();
        String str = null;
        while ((str = br.readLine()) != null) {
            sb.append(str);
        }
        JSONObject jObj = new JSONObject(sb.toString());
        String name = jObj.getString("faculty_name");
        
		// TODO Auto-generated method stub
		//System.out.println(name);
		try{  
			Connection con = DatabaseConnection.initializeDatabase();
			
		
		String sqlUpdate = ("DELETE FROM faculty where faculty_name = ? ");
        
        PreparedStatement st = con 
                .prepareStatement(sqlUpdate);
        
        
        st.setString(1, name); 
       // st.setString(2, request.getParameter("email")); 
        
        
        st.executeUpdate();
        response.sendRedirect("JSP/deletefaculty.jsp");
		}
		catch(Exception e){ System.out.println(e);} 
	}

}
