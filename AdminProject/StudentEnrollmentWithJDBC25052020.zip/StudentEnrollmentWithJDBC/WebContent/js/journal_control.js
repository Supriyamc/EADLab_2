$(document).ready(function(){
	//alert("leave management");
	$.get("../Journal" ,  function(result){
		var js_arr = JSON.parse(result);
	//	alert(js_arr[0].Q1);
		$("#Q1").val(js_arr[0].Q1);
		$("#Q2").val(js_arr[0].Q2);
		$("#Q3").val(js_arr[0].Q3);
		$("#Q4").val(js_arr[0].Q4);		
	});
	
	
});
