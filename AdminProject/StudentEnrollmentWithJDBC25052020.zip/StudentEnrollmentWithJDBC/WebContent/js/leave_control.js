$(document).ready(function(){
	//alert("leave management");
	$.get("../leavemanagement" ,  function(result){
		var js_arr = JSON.parse(result);
		//alert(js_arr[0].CL);
		$("#CL").val(js_arr[0].CL);
		$("#EL").val(js_arr[0].EL);
		$("#RH").val(js_arr[0].RH);
		$("#ML").val(js_arr[0].ML);
		$("#CCL").val(js_arr[0].CCL);
	});
	
	
	
});

