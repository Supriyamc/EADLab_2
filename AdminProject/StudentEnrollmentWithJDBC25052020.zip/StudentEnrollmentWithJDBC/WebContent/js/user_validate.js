$(document).ready(function(){
	//alert("facultyyyyyy!");
	$("#save_id").click(function() {
	var faculty_name = $("#faculty_name").val();
	var faculty_id = $("#faculty_id").val();
	var password = $("#password").val();
	var department = $("#department").val();
	var gender = $("#gender").val();
	var dateofbirth = $("#dateofbirth").val();
	var designation = $("#designation").val();
	var contact_number = $("#contact_number").val();
	var dateofjoining = $("#dateofjoining").val();	
	var email = $("#email").val();
	var natureofappt = $("#natureofappt").val();
	var role = $("#role").val();
	//alert("facultyyyyyy!");
	
		$.post("../user_validate", {faculty_name : faculty_name} ,  function(result){
		var js_arr = JSON.parse(result);
		//alert(js_arr);
		var faculty = ""
		if(js_arr == "") {
			$.post("../Addfaculty", {faculty_name : faculty_name, 
									faculty_id : faculty_id ,
					                password : password ,
					                department : department,
					                gender : gender,
					                dateofbirth : dateofbirth,
					                designation : designation,
					                contact_number : contact_number,
					                dateofjoining : dateofjoining,
					                email : email,
					                natureofappt : natureofappt,
					                role : role
			},
			
					function(result){			
			window.location.href = "faculty.jsp";
			alert("saved successfully");
				
			});
		}
		else {
			alert("User name already exist!!");
		}
		
	});
	
	
});
});