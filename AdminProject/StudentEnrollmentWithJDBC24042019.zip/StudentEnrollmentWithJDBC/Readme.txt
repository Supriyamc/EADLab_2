Changes in this release

1. Add faculty Page is completed
2. Renumeration, Journal, Self appraisal pages are completed, records are getting inserted in the database.(Only update record store in Database is remaining)


New tables created

1.faculty
2.faculty_seq
3.appraisal
4.journal
5.renumeration_configuration

New triggers created

1.tg_faculty_insert

Execute below create statements in sql query window

1.faculty create 

CREATE TABLE `faculty` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `faculty_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `dateofbirth` date DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `contact_number` int(20) DEFAULT NULL,
  `dateofjoining` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `natureofappt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

2.faculty_seq 

CREATE TABLE `faculty_seq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;


3.appraisal

CREATE TABLE `appraisal` (
  `As_Teach` varchar(255) NOT NULL,
  `As_Res` varchar(255) NOT NULL,
  `As_ser` varchar(255) NOT NULL,
  `Asso_Teach` varchar(255) NOT NULL,
  `Asso_Res` varchar(255) NOT NULL,
  `Asso_Ser` varchar(255) NOT NULL,
  `Pro_Teach` varchar(255) NOT NULL,
  `Pro_Res` varchar(255) NOT NULL,
  `Pro_Ser` varchar(255) NOT NULL,
  `Prohead_Teach` varchar(255) NOT NULL,
  `Prohead_Res` varchar(255) NOT NULL,
  `Prohead_Ser` varchar(255) NOT NULL,
  `fci1` varchar(255) NOT NULL,
  `fci2` varchar(255) NOT NULL,
  `fci3` varchar(255) NOT NULL,
  `fci4` varchar(255) NOT NULL,
  `fci5` varchar(255) NOT NULL,
  `nirf1` varchar(255) NOT NULL,
  `index1` varchar(255) NOT NULL,
  `index2` varchar(255) NOT NULL,
  `index3` varchar(255) NOT NULL,
  `jou` varchar(255) NOT NULL,
  `b1` varchar(255) NOT NULL,
  `b2` varchar(255) NOT NULL,
  `dis` varchar(255) NOT NULL,
  `pat` varchar(255) NOT NULL,
  `rUG` varchar(255) NOT NULL,
  `rPG` varchar(255) NOT NULL,
  `rPHD` varchar(255) NOT NULL,
  `fp1` varchar(255) NOT NULL,
  `fp2` varchar(255) NOT NULL,
  `fp3` varchar(255) NOT NULL,
  `fp4` varchar(255) NOT NULL,
  `fp5` varchar(255) NOT NULL,
  `cp1` varchar(255) NOT NULL,
  `cp2` varchar(255) NOT NULL,
  `cp3` varchar(255) NOT NULL,
  `cp4` varchar(255) NOT NULL,
  `cp5` varchar(255) NOT NULL,
  `chair` varchar(255) NOT NULL,
  `cfdp1` varchar(255) NOT NULL,
  `cfdp2` varchar(255) NOT NULL,
  `talk` varchar(255) NOT NULL,
  `eveo` varchar(255) NOT NULL,
  `invi` varchar(255) NOT NULL,
  `ind` varchar(255) NOT NULL,
  `nba1` varchar(255) NOT NULL,
  `nba2` varchar(255) NOT NULL,
  `OS1` varchar(255) NOT NULL,
  `award` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



4.journal

CREATE TABLE `journal` (
  `Q1` varchar(255) NOT NULL,
  `Q2` varchar(255) NOT NULL,
  `Q3` varchar(255) NOT NULL,
  `Q4` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


5.renumeration_configuration

CREATE TABLE `renumeration_configuration` (
  `QPSetting_BE` int(10) DEFAULT NULL,
  `QPSetting_Mtech` int(10) DEFAULT NULL,
  `QPSetting_MCA` int(10) DEFAULT NULL,
  `QPSetting_MBA` int(10) NOT NULL,
  `SSSetting_BE` int(10) NOT NULL,
  `SSSetting_Mtech` int(10) NOT NULL,
  `SSSetting_MCA` int(10) NOT NULL,
  `SSSetting_MBA` int(10) NOT NULL,
  `VMSetting_BE` int(10) NOT NULL,
  `VMSetting_Mtech` int(10) NOT NULL,
  `VMSetting_MCA` int(10) NOT NULL,
  `VMSetting_MBA` int(10) NOT NULL,
  `GPSetting_BE` int(10) NOT NULL,
  `GPSetting_Mtech` int(10) NOT NULL,
  `GPSetting_MCA` int(10) NOT NULL,
  `GPSetting_MBA` int(10) NOT NULL,
  `PESetting_BE` int(10) NOT NULL,
  `PESetting_Mtech` int(10) NOT NULL,
  `PESetting_MCA` int(10) NOT NULL,
  `PESetting_MBA` int(10) NOT NULL,
  `BOSSetting_BE` int(10) NOT NULL,
  `BOSSetting_Mtech` int(10) NOT NULL,
  `BOSSetting_MCA` int(10) NOT NULL,
  `BOSSetting_MBA` int(10) NOT NULL,
  `BOESetting_BE` int(10) NOT NULL,
  `BOESetting_Mtech` int(10) NOT NULL,
  `BOESetting_MCA` int(10) NOT NULL,
  `BOESetting_MBA` int(10) NOT NULL,
  `PVVSetting_BE` int(10) NOT NULL,
  `PVVSetting_Mtech` int(10) NOT NULL,
  `PVVSetting_MCA` int(10) NOT NULL,
  `PVVSetting_MBA` int(10) NOT NULL,
  `PRESetting_BE` int(11) DEFAULT NULL,
  `PRESetting_Mtech` int(11) DEFAULT NULL,
  `PRESetting_MCA` int(11) DEFAULT NULL,
  `PRESetting_MBA` int(11) DEFAULT NULL,
  `SDSetting_BE` int(10) NOT NULL,
  `SDSetting_Mtech` int(10) NOT NULL,
  `SDSetting_MCA` int(10) NOT NULL,
  `SDSetting_MBA` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


6. 

DELIMITER $$
CREATE TRIGGER tg_faculty_insert
BEFORE INSERT ON faculty
FOR EACH ROW
BEGIN
  INSERT INTO faculty_seq VALUES (NULL);
  SET NEW.faculty_id = CONCAT('MSR', LPAD(LAST_INSERT_ID(), 4, '0'));
END
DELIMITER ;

